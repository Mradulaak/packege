library(testthat)
library(descfarspkg)

test_check("descfarspkg")
